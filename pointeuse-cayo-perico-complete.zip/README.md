# Pointeuse Cayo Perico

## Lancer le site

1. Installer Node.js 18 ou plus récent.
2. Ouvrir un terminal dans ce dossier.
3. Exécuter :

   npm install
   npm start

4. Ouvrir http://localhost:3000

## Comptes de démonstration

- Admin : admin / Cayo123!
- Milicien : milicien / Cayo123!

La prime est fixée à 12 500 $ par heure et n'est pas modifiable depuis l'interface.
Les données sont conservées dans data/db.json.
